import { createBrowserRouter } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import Home from '../pages/Home';
import Login from '../pages/Login';
import DashboardPeserta from '../pages/DashboardPeserta';
import DashboardPanitia from '../pages/DashboardPanitia';
import DashboardAdmin from '../pages/DashboardAdmin';
import RuangUjian from '../pages/RuangUjian';
import BankSoal from '../pages/BankSoal'; // 1. Import file halaman bank soal baru
import NotFound from '../pages/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <MainLayout />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: 'login',
        element: <Login />,
      },
      {
        path: 'dashboard-peserta',
        element: <DashboardPeserta />,
      },
      {
        path: 'dashboard-panitia',
        element: <DashboardPanitia />,
      },
      {
        path: 'dashboard-admin',
        element: <DashboardAdmin />,
      },
      {
        path: 'ruang-ujian',
        element: <RuangUjian />,
      },
      {
        path: 'bank-soal', // 2. Daftarkan rute url manajemen bank soal
        element: <BankSoal />,
      },
      {
        path: '*',
        element: <NotFound />,
      },
    ],
  },
]);