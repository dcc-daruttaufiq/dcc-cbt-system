import axios from 'axios';

// Membuat instance axios dengan base URL backend Anda
const API = axios.create({
  baseURL: 'http://localhost:5000/api',
});

// Interceptor otomatis cek localStorage ATAU sessionStorage
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token') || sessionStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

export default API;