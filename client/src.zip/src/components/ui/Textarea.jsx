import React from 'react';
import { cn } from '../../utils/cn';

export default function Textarea({ className, label, error, ...props }) {
  return (
    <div className="w-full flex flex-col gap-1.5">
      {label && <label className="text-sm font-sans font-medium text-slate-300">{label}</label>}
      <textarea
        className={cn(
          "w-full px-3 py-2 bg-surface border border-customBorder rounded-lg text-white font-sans placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all text-sm min-h-[100px]",
          error && "border-red-500 focus:ring-red-500/50 focus:border-red-500",
          className
        )}
        {...props}
      />
      {error && <span className="text-xs text-red-400 font-sans">{error}</span>}
    </div>
  );
}
