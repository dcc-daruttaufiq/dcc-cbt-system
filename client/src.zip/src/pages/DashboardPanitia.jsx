import React, { useState, useEffect } from 'react';
import API from '../utils/api';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { CheckSquare, Square, Award, ClipboardList, User } from 'lucide-react';

export default function DashboardPanitia() {
  const [peserta, setPeserta] = useState([]);
  const [selectedSiswa, setSelectedSiswa] = useState(null);
  const [detailJawaban, setDetailJawaban] = useState([]);
  
  // State untuk checklist kriteria praktik dinamis
  const [checklistPraktik, setChecklistPraktik] = useState({});
  const [hasilNilai, setHasilNilai] = useState(null);

  // Load daftar siswa yang sudah beres ujian
  useEffect(() => {
    loadPeserta();
  }, []);

  const loadPeserta = async () => {
    try {
      const res = await API.get('/ujian/peserta');
      setPeserta(res.data);
    } catch (err) {
      console.error('Gagal memuat peserta', err);
    }
  };

  // Pilih siswa untuk mulai proses scoring/penilaian
  const handlePeriksa = async (userId) => {
    setSelectedSiswa(userId);
    setHasilNilai(null);
    try {
      const res = await API.get(`/ujian/peserta/${userId}`);
      setDetailJawaban(res.data);
      
      // Kumpulkan kriteria checklist dari soal praktik yang ada
      const initChecklist = {};
      res.data.forEach(j => {
        if (j.tipe === 'praktik' && j.checklist) {
          const kriteriaArr = typeof j.checklist === 'string' ? JSON.parse(j.checklist) : j.checklist;
          kriteriaArr.forEach((kriteria, idx) => {
            initChecklist[`${j.soal_id}-${idx}`] = false; // default belum dicentang panitia
          });
        }
      });
      setChecklistPraktik(initChecklist);
    } catch (err) {
      alert('Gagal memuat lembar jawaban siswa.');
    }
  };

  // Logika Checklist Praktik & Auto Hitung Real-time
  const toggleChecklist = (key) => {
    setChecklistPraktik(prev => {
      const updated = { ...prev, [key]: !prev[key] };
      return updated;
    });
  };

  // Hitung otomatis nilai praktik dari checklist yang aktif sebelum dikirim ke backend
  const hitungSkorPraktikLokal = () => {
    const keys = Object.keys(checklistPraktik);
    if (keys.length === 0) return 0;
    const dicentang = keys.filter(k => checklistPraktik[k] === true).length;
    return Math.round((dicentang / keys.length) * 100);
  };

  // Kirim penilaian ke backend buat digabung dengan Nilai PG Otomatis
  const submitPenilaian = async () => {
    const skorPraktikTotal = hitungSkorPraktikLokal();
    try {
      const res = await API.post('/ujian/hitung-nilai', {
        userId: selectedSiswa,
        skorPraktik: skorPraktikTotal
      });
      setHasilNilai(res.data);
      alert('Nilai akhir berhasil dikunci oleh server!');
      loadPeserta(); // refresh list dashboard
    } catch (err) {
      alert('Gagal memproses kalkulasi nilai terpusat.');
    }
  };

  return (
    <div className="p-6 text-white max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-2 border-b border-customBorder pb-4">
        <ClipboardList className="text-primary w-7 h-7" />
        <h1 className="text-2xl font-display font-bold">DASHBOARD PANITIA — PANEL PENILAIAN</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* KOLOM KIRI: DAFTAR PESERTA SELESAI UJIAN */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Antrean Ujian Selesai</h2>
          {peserta.length === 0 ? (
            <Card className="p-4 text-center text-slate-500 text-sm">Belum ada peserta yang mengumpulkan ujian.</Card>
          ) : (
            peserta.map((p, idx) => (
              <Card key={idx} className={`p-4 border transition ${selectedSiswa === p.user_id ? 'border-primary bg-primary/5' : 'border-customBorder bg-surface'}`}>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-darkBg rounded-lg border border-customBorder"><User className="w-5 h-5 text-slate-400" /></div>
                    <div>
                      <h4 className="font-semibold text-sm">Peserta ID: {p.user_id}</h4>
                      <p className="text-xs text-slate-400">{p.total_dijawab} Soal Terjawab</p>
                    </div>
                  </div>
                  <Button size="sm" onClick={() => handlePeriksa(p.user_id)}>Periksa</Button>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* KOLOM TENGAH & KANAN: PANEL LEMBAR JAWABAN & CHECKLIST PRAKTIK */}
        <div className="lg:col-span-2">
          {selectedSiswa ? (
            <div className="space-y-6">
              <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Lembar Koreksi Jawaban</h2>
              
              {detailJawaban.map((j, idx) => (
                <Card key={idx} className="p-6 border-customBorder bg-surface space-y-4">
                  <div className="flex justify-between items-center border-b border-customBorder/40 pb-2">
                    <Badge variant={j.tipe === 'pg' ? 'primary' : 'secondary'} className="capitalize">Soal {j.tipe}</Badge>
                  </div>
                  <p className="text-sm text-slate-200 font-medium">{j.pertanyaan}</p>
                  
                  {/* Tampilan Jawaban Siswa */}
                  <div className="p-4 bg-darkBg/60 border border-customBorder/50 rounded-xl text-sm">
                    <p className="text-xs text-slate-500 mb-1 font-semibold">JAWABAN SISWA:</p>
                    <p className="text-slate-100 font-mono break-words">
                      {j.tipe === 'pg' ? j.jawaban : (typeof j.jawaban === 'string' && j.jawaban.startsWith('{') ? JSON.parse(j.jawaban).teks : j.jawaban)}
                    </p>
                    {j.tipe === 'praktik' && typeof j.jawaban === 'string' && j.jawaban.includes('fileName') && (
                      <div className="mt-2 text-xs text-secondary underline">
                        📄 File Terlampir: {JSON.parse(j.jawaban).fileName}
                      </div>
                    )}
                  </div>

                  {/* KELOMPOK CHECKLIST PRAKTIK DI SISI PANITIA */}
                  {j.tipe === 'praktik' && j.checklist && (
                    <div className="bg-background/40 border border-amber-500/20 p-4 rounded-xl space-y-3">
                      <p className="text-xs font-bold text-amber-500 uppercase tracking-wide">Checklist Kriteria Penilaian Praktik:</p>
                      <div className="space-y-2">
                        {(typeof j.checklist === 'string' ? JSON.parse(j.checklist) : j.checklist).map((kriteria, kIdx) => {
                          const key = `${j.soal_id}-${kIdx}`;
                          const isChecked = checklistPraktik[key];
                          return (
                            <div key={kIdx} onClick={() => toggleChecklist(key)} className="flex items-center gap-3 p-2 bg-darkBg/30 border border-customBorder/30 rounded-lg cursor-pointer hover:bg-white/5 transition text-sm">
                              {isChecked ? <CheckSquare className="w-4 h-4 text-primary" /> : <Square className="w-4 h-4 text-slate-500" />}
                              <span className={isChecked ? 'text-primary font-medium' : 'text-slate-300'}>{kriteria}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </Card>
              ))}

              {/* ACTION HITUNG & HASIL AKHIR */}
              <Card className="p-6 border border-primary/20 bg-gradient-to-r from-surface to-primary/5 rounded-xl flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <h3 className="font-bold text-base flex items-center gap-2"><Award className="text-primary w-5 h-5" /> Ringkasan Nilai Akhir</h3>
                  <p className="text-xs text-slate-400">Nilai PG dihitung otomatis oleh core server, Nilai Praktik dikalkulasi via live checklist.</p>
                </div>
                
                <div className="flex items-center gap-4">
                  {hasilNilai && (
                    <div className="text-center bg-darkBg px-4 py-2 rounded-xl border border-customBorder font-mono">
                      <div className="text-xs text-slate-400">TOTAL SKOR</div>
                      <div className="text-2xl font-bold text-green-400">{hasilNilai.nilaiAkhir}</div>
                    </div>
                  )}
                  <Button variant="primary" size="md" onClick={submitPenilaian}>Kunci & Auto Hitung Nilai</Button>
                </div>
              </Card>
            </div>
          ) : (
            <Card className="p-10 text-center text-slate-500 border-dashed border-2 border-customBorder">
              Silakan pilih peserta di bilah kiri untuk memuat lembar jawaban dan memulai kriteria checklist penilaian.
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}