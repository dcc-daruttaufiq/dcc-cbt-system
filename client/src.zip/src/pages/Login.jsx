import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import API from '../utils/api';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Card from '../components/ui/Card';
import Alert from '../components/ui/Alert';
import { GraduationCap, ShieldAlert } from 'lucide-react';

export default function Login() {
  useDocumentTitle('Login Portal Ujian');
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false); // State untuk Remember Login

  const handleAdminSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!username.trim() || !password.trim()) {
      return setError('Username dan password wajib diisi.');
    }

    try {
      console.log('🚀 Frontend mengirim data login:', { username, password });
      
      const response = await API.post('/auth/login', {
        username: username,
        password: password,
      });

      // Pengecekan aman berlapis untuk mencakup struktur data objek dari backend lu
      const token = response.data?.token;
      const role = response.data?.user?.role || response.data?.role;
      const nama = response.data?.user?.name || response.data?.user?.nama || response.data?.nama;

      if (!token) {
        return setError('Token login tidak ditemukan dari respons server.');
      }

      // HANDLE REMEMBER ME / SESSION STORAGE
      if (rememberMe) {
        localStorage.setItem('token', token);
        localStorage.setItem('role', role || 'admin');
        localStorage.setItem('nama', nama || 'Super Admin DCC');
      } else {
        sessionStorage.setItem('token', token);
        sessionStorage.setItem('role', role || 'admin');
        sessionStorage.setItem('nama', nama || 'Super Admin DCC');
      }

      setSuccess(`Selamat datang ${nama || 'Admin'}! Mengalihkan...`);
      
      setTimeout(() => {
        navigate('/bank-soal');
      }, 1500);

    } catch (err) {
      console.error('❌ Login gagal, detail error:', err);
      setError(err.response?.data?.message || 'Gagal terhubung ke server backend.');
    }
  };

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center px-4 text-white">
      <div className="w-full max-w-md text-center mb-6">
        <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-surface border border-customBorder mb-4 shadow-xl shadow-primary/5">
          <GraduationCap className="w-10 h-10 text-primary" />
        </div>
        <h1 className="text-4xl text-white font-display font-bold tracking-wider">PORTAL CBT</h1>
        <p className="text-slate-400 font-sans text-sm mt-1">Sistem Otentikasi Terintegrasi Database SQLite</p>
      </div>

      <Card className="w-full max-w-md p-6 border border-customBorder/80 shadow-2xl bg-surface">
        <div className="bg-darkBg p-2 text-center rounded-xl border border-customBorder/40 mb-6 text-xs font-display font-bold tracking-wider text-primary uppercase">
          SECURE TERMINAL LOGIN (ADMIN)
        </div>

        <AnimatePresence mode="wait">
          {error && <div className="mb-4"><Alert variant="danger">{error}</Alert></div>}
          {success && <div className="mb-4"><Alert variant="success">{success}</Alert></div>}
        </AnimatePresence>

        <form onSubmit={handleAdminSubmit} className="space-y-4">
          <Input
            label="Kredensial Administrator"
            placeholder="Masukkan username (admin)..."
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <Input
            type="password"
            label="Security Password"
            placeholder="Masukkan password (admin123)..."
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          
          {/* Checkbox Remember Me */}
          <div className="flex items-center space-x-2 py-1 text-sm text-slate-400">
            <input
              type="checkbox"
              id="remember"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="accent-primary h-4 w-4 rounded bg-darkBg border-customBorder"
            />
            <label htmlFor="remember" className="cursor-pointer select-none">Remember Login</label>
          </div>

          <Button type="submit" className="w-full mt-2 bg-red-600 hover:bg-red-500 text-white shadow-none border border-red-500/30">
            <ShieldAlert className="w-4 h-4 mr-2" /> Connect to Central Core
          </Button>
        </form>
      </Card>
    </div>
  );
}